#import "BaseClassForAllSVGBasicShapes.h"
#import "BaseClassForAllSVGBasicShapes_ForSubclasses.h"

@interface SVGPolylineElement : BaseClassForAllSVGBasicShapes { }

@end
