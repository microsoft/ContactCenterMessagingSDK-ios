//
//  ACRBadgeRenderer.h
//  AdaptiveCards
//
//  Created by reenulnu on 08/10/24.
//  Copyright © 2024 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRBadgeRenderer : ACRBaseCardElementRenderer

+ (ACRBadgeRenderer *)getInstance;
@end
