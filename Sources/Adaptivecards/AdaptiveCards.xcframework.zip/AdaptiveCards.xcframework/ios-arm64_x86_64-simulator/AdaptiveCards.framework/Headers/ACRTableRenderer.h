//
//  ACRTableRenderer
//  ACRTableRenderer.h
//
//  Copyright © 2021 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRTableRenderer : ACRBaseCardElementRenderer

+ (ACRTableRenderer *)getInstance;

@end
