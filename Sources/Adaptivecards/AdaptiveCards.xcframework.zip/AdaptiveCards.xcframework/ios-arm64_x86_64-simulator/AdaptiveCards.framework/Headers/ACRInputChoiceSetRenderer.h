//
//  ACRInputChoiceSetRenderer
//  ACRInputChoiceSetRenderer.h
//
//  Copyright © 2018 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRInputChoiceSetRenderer : ACRBaseCardElementRenderer

+ (ACRInputChoiceSetRenderer *)getInstance;

@end
