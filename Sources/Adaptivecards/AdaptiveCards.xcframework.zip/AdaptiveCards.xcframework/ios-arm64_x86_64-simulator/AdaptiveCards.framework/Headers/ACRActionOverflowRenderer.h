//
//  ACRActionOverflowRenderer
//  ACRActionOverflowRenderer.h
//
//  Copyright © 2021 Microsoft. All rights reserved.
//

#import "ACRBaseActionElementRenderer.h"

@interface ACRActionOverflowRenderer : ACRBaseActionElementRenderer

+ (ACRActionOverflowRenderer *)getInstance;

@end
