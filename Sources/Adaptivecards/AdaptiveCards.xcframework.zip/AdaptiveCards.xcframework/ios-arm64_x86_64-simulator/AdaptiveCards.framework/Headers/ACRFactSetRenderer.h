//
//  ACRFactSetRenderer
//  ACRFactSetRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRFactSetRenderer : ACRBaseCardElementRenderer

+ (ACRFactSetRenderer *)getInstance;

@end
